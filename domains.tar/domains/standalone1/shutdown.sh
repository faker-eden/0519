#!/bin/sh

. ./env.sh 

$JBOSS_HOME/bin/jboss-cli.sh --connect --controller=192.168.219.199:9990 --command=:shutdown
