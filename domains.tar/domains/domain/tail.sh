#!/bin/sh

. ./env.sh 

tail -f log/server.log
